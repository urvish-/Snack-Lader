﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SnackLadertry
{
    class Program
    {
        static int GenerateDigit(Random rnd)
        {
            // Assume there'd be more logic here really
            int i= 0;
            do
            {
                i = rnd.Next(7);
            } while (i < 1);
            return i;
        }
        static void Main(string[] args)
        {
            Console.Write("Welcome to snack and lader!");
            Console.ReadLine();
            Dictionary<int, int> dSnack = new Dictionary<int, int>();
            Dictionary<int, int> dLadder = new Dictionary<int, int>();

           List<List<int>> SnackList = new List<List<int>>();
            List<int> Snack = new List<int>();
            List<List<int>> LadderList = new List<List<int>>();
            List<int> Lader = new List<int>();
            
            string[] temp;
            int dice=0;
            int Kuki = 0;
            Random rnd = new Random();
            Console.WriteLine("Please enter 5 Snack slides!");
            for (int i=0; i < 5; i++)
            {
                string s = Console.ReadLine();
                
                temp = s.Split( );
                dSnack.Add(int.Parse(temp[0]), int.Parse(temp[1]));
            }
            Console.WriteLine("Please enter 5 Lader slides!");
            for (int i = 0; i < 5; i++)
            {
                string s = Console.ReadLine();

                temp = s.Split();
                dLadder.Add(int.Parse(temp[0]), int.Parse(temp[1]));
            }
            int stepCounter = 0;
            int flag = 0;
            Console.WriteLine("We have now Snack and lader details stored.");
            Console.WriteLine("Start the game by rolling dice.Press any Key to countinue...");
            Console.ReadLine();
            while (Kuki < 100)
            {
                stepCounter++;
                dice = GenerateDigit(rnd);
                Console.WriteLine("DIce rolled value: "+dice);
                Kuki += dice;
                foreach (var sl in dSnack) {
                    flag = 0;
                    if (Kuki == sl.Key)
                        {
                        Kuki = sl.Value;
                        flag = 1;
                        Console.WriteLine("Oops snack caught you here at "+sl.Key);
                        break;
                    }
                }
                if(flag == 0)
                {
                    foreach (var la in dLadder)
                    {
                        if (Kuki == la.Key)
                        {
                            Kuki = la.Value;
                            Console.WriteLine("Huviii..you got lader at :"+ la.Key);
                            break;
                        }
                    }

                }
                Console.WriteLine("Yor position now:"+ Kuki);
                Console.ReadLine();
            }
            Console.WriteLine("Congratulation!!!You have completed game in "+ stepCounter+" Steps!");
            Console.ReadLine();
            //List<int> Snack

        }
    }
}

//Test Data:
//Snack
//11 5
//23 2
//44 34
//73 21
//98 76


//Lader
//8 24
//17 73
//48 63
//64 99
//79 91